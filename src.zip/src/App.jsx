import React from 'react'

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h1>Welcome to SimBank v2</h1>
      <p>This is the Vercel-ready version of your simulated banking app.</p>
    </div>
  )
}
